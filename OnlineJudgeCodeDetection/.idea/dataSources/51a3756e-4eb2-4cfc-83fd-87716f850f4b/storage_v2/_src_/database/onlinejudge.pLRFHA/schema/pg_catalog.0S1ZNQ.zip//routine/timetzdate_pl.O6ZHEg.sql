CREATE FUNCTION timetzdate_pl(time with time zone, date) RETURNS timestamp with time zone
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select ($2 + $1)$$;

COMMENT ON FUNCTION timetzdate_pl(TIME WITH TIME ZONE, DATE) IS 'implementation of + operator';

ALTER FUNCTION timetzdate_pl(TIME WITH TIME ZONE, DATE) OWNER TO onlinejudge;

