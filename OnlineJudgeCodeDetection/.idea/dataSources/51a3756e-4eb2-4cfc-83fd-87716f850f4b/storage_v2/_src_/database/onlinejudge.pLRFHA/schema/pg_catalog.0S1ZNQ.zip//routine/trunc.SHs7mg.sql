CREATE FUNCTION trunc(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select pg_catalog.trunc($1,0)$$;

COMMENT ON FUNCTION trunc(NUMERIC) IS 'value truncated to ''scale'' of zero';

ALTER FUNCTION trunc(NUMERIC) OWNER TO onlinejudge;

