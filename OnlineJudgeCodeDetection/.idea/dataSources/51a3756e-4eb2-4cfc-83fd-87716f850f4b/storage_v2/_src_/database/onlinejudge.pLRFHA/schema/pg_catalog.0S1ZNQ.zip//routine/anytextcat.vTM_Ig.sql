CREATE FUNCTION anytextcat(anynonarray, text) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select $1::pg_catalog.text || $2$$;

COMMENT ON FUNCTION anytextcat(ANYNONARRAY, TEXT) IS 'implementation of || operator';

ALTER FUNCTION anytextcat(ANYNONARRAY, TEXT) OWNER TO onlinejudge;

