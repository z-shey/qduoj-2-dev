CREATE FUNCTION integer_pl_date(integer, date) RETURNS date
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select $2 + $1$$;

COMMENT ON FUNCTION integer_pl_date(INTEGER, DATE) IS 'implementation of + operator';

ALTER FUNCTION integer_pl_date(INTEGER, DATE) OWNER TO onlinejudge;

