CREATE FUNCTION interval_pl_date(interval, date) RETURNS timestamp without time zone
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select $2 + $1$$;

COMMENT ON FUNCTION interval_pl_date(INTERVAL, DATE) IS 'implementation of + operator';

ALTER FUNCTION interval_pl_date(INTERVAL, DATE) OWNER TO onlinejudge;

