CREATE FUNCTION "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) RETURNS boolean
    STABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select ($1, ($1 + $2)) overlaps ($3, ($3 + $4))$$;

COMMENT ON FUNCTION "overlaps"(TIMESTAMP WITH TIME ZONE, INTERVAL, TIMESTAMP WITH TIME ZONE, INTERVAL) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(TIMESTAMP WITH TIME ZONE, INTERVAL, TIMESTAMP WITH TIME ZONE, INTERVAL) OWNER TO onlinejudge;

