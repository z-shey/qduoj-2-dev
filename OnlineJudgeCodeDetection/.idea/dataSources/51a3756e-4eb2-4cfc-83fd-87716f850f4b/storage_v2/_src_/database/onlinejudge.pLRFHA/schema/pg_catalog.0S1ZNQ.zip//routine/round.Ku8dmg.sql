CREATE FUNCTION round(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select pg_catalog.round($1,0)$$;

COMMENT ON FUNCTION round(NUMERIC) IS 'value rounded to ''scale'' of zero';

ALTER FUNCTION round(NUMERIC) OWNER TO onlinejudge;

