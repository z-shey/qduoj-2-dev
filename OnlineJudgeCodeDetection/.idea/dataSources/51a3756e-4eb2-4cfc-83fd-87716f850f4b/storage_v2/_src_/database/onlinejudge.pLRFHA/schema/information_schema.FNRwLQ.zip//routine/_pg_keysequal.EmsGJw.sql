CREATE FUNCTION _pg_keysequal(smallint[], smallint[]) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    LANGUAGE sql
AS
$$select $1 operator(pg_catalog.<@) $2 and $2 operator(pg_catalog.<@) $1$$;

ALTER FUNCTION _pg_keysequal(SMALLINT[], SMALLINT[]) OWNER TO onlinejudge;

